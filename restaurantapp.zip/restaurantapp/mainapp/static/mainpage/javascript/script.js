$(document).ready(function(){

    $('#menu-bar').click(function(){
        $(this).toggleClass('fa-times');
        $('.navbar').toggleClass('nav-toggle');
    });
    $(window).on('load scroll',function(){

        $('#menu-bar').removeClass('fa-times');
        $('.navbar').removeClass('nav-toggle');

        $('section').each(function(){

            let top = $(window).scrollTop();
            let height = $(this).height();
            let id = $(this).attr('id');
            let offset = $(this).offset().top - 200;

            if(top > offset && top < offset + height){
                $('.navbar ul li a').removeClass('active');
                $('.navbar').find(`[href="#${id}"]`).addClass('active');
            }

        });

    });
    $('.menu .list .btn').click(function(){
        $(this).addClass('active').siblings().removeClass('active');
        let src = $(this).attr('data-src');
        $('#menu-img').attr('src',src);
        let src2 = $(this).attr('data-src1');
        $('#menu-img1').attr('src',src2);
        let src3 = $(this).attr('data-src2');
        $('#menu-img2').attr('src',src3);
    });
    $('.buy').click(function(){
        $('.bottom').addClass("clicked");
    });

    $('.remove').click(function(){
         $('.bottom').removeClass("clicked");
    });
});